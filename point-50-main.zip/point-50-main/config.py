from telethon.sync import TelegramClient
from telethon.sessions import StringSession
import os
APP_ID = os.environ.get("APP_ID")
APP_HASH = os.environ.get("APP_HASH")
BOT_USERNAME = os.environ.get("BOT_USERNAME")
session1 = os.environ.get("TERMUX")
SESSION1 = os.environ.get("TERMUX")
token = os.environ.get("TOKEN")
DEVLOO = os.environ.get("DEVLO")

shahm1 = TelegramClient(StringSession(session1), APP_ID, APP_HASH)
bot = TelegramClient("bot", APP_ID, APP_HASH).start(bot_token=token)


session2 = os.environ.get("TERMUXX")
SESSION2 = os.environ.get("TERMUXX")
shahm2 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)


session3 = os.environ.get("TERMUXXX")
SESSION3 = os.environ.get("TERMUXXX")
shahm3 = TelegramClient(StringSession(session3), APP_ID, APP_HASH)


session4 = os.environ.get("TERMUXXXX")
SESSION4 = os.environ.get("TERMUXXXX")
shahm4 = TelegramClient(StringSession(session4), APP_ID, APP_HASH)


session5 = os.environ.get("TERMUXXXXX")
SESSION5 = os.environ.get("TERMUXXXXX")
shahm5 = TelegramClient(StringSession(session5), APP_ID, APP_HASH)

session6 = os.environ.get("TERMUXSI")
SESSION6 = os.environ.get("TERMUXSI")
shahm6 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)

session7 = os.environ.get("TERMUXSE")
SESSION7 = os.environ.get("TERMUXSE")
shahm7 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)

session8 = os.environ.get("TERMUXEI")
SESSION8 = os.environ.get("TERMUXEI")
shahm8 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)

session9 = os.environ.get("TERMUXNI")
SESSION9 = os.environ.get("TERMUXNI")
shahm9 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)

session10 = os.environ.get("TERMUXTE")
SESSION10 = os.environ.get("TERMUXTE")
shahm10 = TelegramClient(StringSession(session2), APP_ID, APP_HASH)

ispay = ['yes']
ispay2 = ['yes']
bot.start()

