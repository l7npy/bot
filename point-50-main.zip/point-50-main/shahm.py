from telethon.tl.functions.channels import LeaveChannelRequest







import telethon







from time import sleep







from telethon import events







from config import *







import os







import logging







import asyncio







import time







from telethon.tl import functions, types







from telethon.tl.functions.messages import ImportChatInviteRequest as Get







from telethon.utils import get_display_name







from telethon.tl.functions.channels import JoinChannelRequest







from telethon.errors import FloodWaitError







from telethon import TelegramClient, events







from collections import deque







from telethon import functions







from telethon.errors.rpcerrorlist import (







    UserAlreadyParticipantError,







    UserNotMutualContactError,







    UserPrivacyRestrictedError,







)







from telethon.tl.functions.channels import InviteToChannelRequest







from telethon.tl.types import InputPeerUser







from telethon.errors.rpcerrorlist import YouBlockedUserError







from telethon.tl import functions







from hijri_converter import Gregorian







from telethon.tl.functions.channels import LeaveChannelRequest







import datetime







from telethon.tl.functions.messages import GetHistoryRequest







from telethon.tl.functions.messages import ImportChatInviteRequest







import requests







# -















# -















shahm1.start()







shahm2.start()







shahm3.start()







shahm4.start()







shahm5.start()







shahm6.start()







shahm7.start()







shahm8.start()







shahm9.start()







shahm10.start()















c = requests.session()







bot_username = '@zmmbot'







bot_usernamee = '@A_MAN9300BOT'







bot_usernameee = '@MARKTEBOT'







bot_usernameeee = '@xnsex21bot'















ownerhson_id = (int(DEVLOO))







LOGS = logging.getLogger(__name__)







DEVS = [5159123009]























async def join_channel():







    try:







        await shahm(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass























@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass























@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass























@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@RRXDR"))







    except BaseException:







        pass







        







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@RRXJR"))







    except BaseException:







        pass







        







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@RRXOR"))







    except BaseException:







        pass







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@RRXBR"))







    except BaseException:







        pass







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@RRXFR"))







    except BaseException:







        pass







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@KTTTT"))







    except BaseException:







        pass







        







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@zzzzzz"))







    except BaseException:







        pass







        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@zz_MX"))







    except BaseException:







        pass 















@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@ql8ql"))







    except BaseException:







        pass        







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@zN_E4"))







    except BaseException:







        pass















@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@sh_tem"))







    except BaseException:







        pass







        







    































@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm1(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm2.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm2(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass







        







        







@shahm3.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm3(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass























@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm4.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm4(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm5.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm5(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







        







@shahm1.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm2.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')























@shahm3.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')























@shahm4.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm5.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm1.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm2.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm3.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")























@shahm4.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm5.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















































@shahm1.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm2.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm3.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")















@shahm4.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm5.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")















@shahm1.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm1.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_username)







    await shahm1.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm1.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernamee)







    await shahm1.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm1.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernameee)







    await shahm1.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm1.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernameeee)







    await shahm1.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm1.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_username)







    await shahm1.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm1.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernamee)







    await shahm1.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm1.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernameee)







    await shahm1.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm1.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm1(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm1.get_entity(bot_usernameeee)







    await shahm1.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm1(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm1.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm1(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm1(ImportChatInviteRequest(bott))







            msg2 = await shahm1.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm1.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm1.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























##########################################















@shahm2.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):















    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm2.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_username)







    await shahm2.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm2.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernamee)







    await shahm2.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm2.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernameee)







    await shahm2.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm2.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernameeee)







    await shahm2.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm2.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_username)







    await shahm2.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm2.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernamee)







    await shahm2.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm2.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernameee)







    await shahm2.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm2.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm2(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm2.get_entity(bot_usernameeee)







    await shahm2.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm2(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm2.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm2(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm2(ImportChatInviteRequest(bott))







            msg2 = await shahm2.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm2.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm2.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm3.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm3.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_username)







    await shahm3.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm3.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernamee)







    await shahm3.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm3.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernameee)







    await shahm3.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm3.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernameeee)







    await shahm3.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm3.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_username)







    await shahm3.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm3.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernamee)







    await shahm3.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm3.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernameee)







    await shahm3.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm3.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm3(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm3.get_entity(bot_usernameeee)







    await shahm3.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm3(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm3.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm3(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm3(ImportChatInviteRequest(bott))







            msg2 = await shahm3.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm3.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm3.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm4.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘??𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm4.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_username)







    await shahm4.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm4.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernamee)







    await shahm4.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm4.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernameee)







    await shahm4.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm4.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernameeee)







    await shahm4.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm4.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_username)







    await shahm4.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm4.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernamee)







    await shahm4.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm4.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernameee)







    await shahm4.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm4.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm4(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm4.get_entity(bot_usernameeee)







    await shahm4.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm4(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm4.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm4(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm4(ImportChatInviteRequest(bott))







            msg2 = await shahm4.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm4.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm4.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm5.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm5.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_username)







    await shahm5.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm5.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernamee)







    await shahm5.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm5.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernameee)







    await shahm5.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm5.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernameeee)







    await shahm5.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm5.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_username)







    await shahm5.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm5.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernamee)







    await shahm5.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm5.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernameee)







    await shahm5.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm5.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm5(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm5.get_entity(bot_usernameeee)







    await shahm5.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm5(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm5.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm5(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm5(ImportChatInviteRequest(bott))







            msg2 = await shahm5.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm5.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm5.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







































@shahm1.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm1.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm1.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm1.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm1.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm1.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm1.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm1.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm1.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm1.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm1.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm1.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm1.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm1.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm1(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm2.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm2.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm2.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm2.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm2.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm2.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm2.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm2.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm2.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm2.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm2.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm2.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm2.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm2.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm2(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm3.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm3.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm3.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm3.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm3.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm3.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm3.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm3.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm3.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm3.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm3.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm3.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm3.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm3.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm3(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm4.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm4.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm4.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm4.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm4.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm4.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm4.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm4.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm4.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm4.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm4.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm4.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm4.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm4.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm4(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm5.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm5.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm5.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm5.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm5.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm5.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm5.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm5.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm5.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm5.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm5.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm5.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm5.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm5.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm5(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







       















@shahm1.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm1.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**")    







    







    







@shahm2.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm2.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**")    







    







@shahm3.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm3.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 















@shahm4.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm4.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 















@shahm5.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm5.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 























@shahm1.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm2.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm3.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")























@shahm4.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm5.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")























@shahm1.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm2.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm3.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")























@shahm4.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm5.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")























@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm6(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm7.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm7(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass







        







        







@shahm8.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm8(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass























@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm9.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm9(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@d3boot_7"))







    except BaseException:







        pass















        















        















@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@DzDDDD"))







    except BaseException:







        pass















        















@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@botbillion"))







    except BaseException:







        pass















        















        















@shahm10.on(events.NewMessage)







async def join_channel(event):







    try:







        await shahm10(JoinChannelRequest("@fvvvv"))







    except BaseException:







        pass







        







        







@shahm6.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm7.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')























@shahm8.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')























@shahm9.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm10.on(events.NewMessage(outgoing=False, pattern='/TEST'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply('**the source is running ⚡️**')















@shahm6.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm7.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm8.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")























@shahm9.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















@shahm10.on(events.NewMessage(outgoing=False, pattern='.الاوامر'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`







• SEND - `/TEST`







• LEAVE CHANNEL & GROUP - `/lpoint`







• TRANSFER PT - `/transfer`







• INFO ACCOUNT - `/infoacc`**""")















































@shahm6.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm7.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm8.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")















@shahm9.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")























@shahm10.on(events.NewMessage(outgoing=True, pattern=".الاوامر"))







async def _(event):







      await event.edit("""**〠 اوامر حساب المسؤول















• @ZMMBOT - `/point1`







• @A_MAN9300BOT - `/point2`







• @MARKTEBOT - `/point3`







• @XNSEX21BOT - `/point4`































〠 اوامر حساب المستخدم 















• بوت تمويل المليار  - `.تجميع المليار`















• بوت تمويل الجوكر - `.تجميع الجوكر`















• بوت تمويل العقـاب - `.تجميع العقاب`















• بوت تمويل العـرب  - `.تجميع العرب `















• فحص السورس      - `.فحص`**""")















@shahm6.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm6.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_username)







    await shahm6.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm6.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernamee)







    await shahm6.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm6.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernameee)







    await shahm6.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm6.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernameeee)







    await shahm6.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm6.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_username)







    await shahm6.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm6.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernamee)







    await shahm6.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm6.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernameee)







    await shahm6.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm6.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm6(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm6.get_entity(bot_usernameeee)







    await shahm6.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm6(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm6.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm6(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm6(ImportChatInviteRequest(bott))







            msg2 = await shahm6.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm6.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm6.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























##########################################















@shahm7.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):















    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm7.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_username)







    await shahm7.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm7.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernamee)







    await shahm7.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm7.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernameee)







    await shahm7.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm7.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernameeee)







    await shahm7.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm7.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_username)







    await shahm7.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm7.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernamee)







    await shahm7.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm7.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernameee)







    await shahm7.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm7.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm7(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm7.get_entity(bot_usernameeee)







    await shahm7.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm7(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm7.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm7(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm7(ImportChatInviteRequest(bott))







            msg2 = await shahm7.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm7.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm7.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm8.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm8.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_username)







    await shahm8.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm8.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernamee)







    await shahm8.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm8.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernameee)







    await shahm8.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm8.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernameeee)







    await shahm8.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm8.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_username)







    await shahm8.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm8.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernamee)







    await shahm8.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm8.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernameee)







    await shahm8.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm8.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm8(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm8.get_entity(bot_usernameeee)







    await shahm8.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm8(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm8.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm8(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm8(ImportChatInviteRequest(bott))







            msg2 = await shahm8.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm8.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm8.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm9.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘??𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm9.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_username)







    await shahm9.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm9.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernamee)







    await shahm9.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm9.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernameee)







    await shahm9.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm9.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernameeee)







    await shahm9.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm9.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_username)







    await shahm9.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm9.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernamee)







    await shahm9.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm9.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernameee)







    await shahm9.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm9.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm9(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm9.get_entity(bot_usernameeee)







    await shahm9.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm9(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm9.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm9(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm9(ImportChatInviteRequest(bott))







            msg2 = await shahm9.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm9.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm9.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm10.on(events.NewMessage(outgoing=True, pattern=r"\.فحص"))







async def _(event):







	







    start = datetime.datetime.now()







    await event.edit("**جاري الفحص..**")







    end = datetime.datetime.now()







    ms = (end - start).microseconds / 1000







    await event.edit(f'''







╭──⌯𝗦𝗢𝗨𝗥𝗖𝗘 𝗦𝗬𝗧𝗛𝗢𝗡⌯──╮















※ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 -  𝗦𝗔𝗬𝗧𝗛𝗢𝗡𝗛    ※















※ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 - 𝟭.𝟬 - 𝗥𝗘𝗩𝗜𝗦𝗘𝗗   ※















※ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 - 𝗛𝗨𝗦𝗔𝗠.𝗙𝗔  ※















╰───⌯𝗦𝗬𝗧𝗛𝗢𝗡 𝗣𝗢𝗜𝗡𝗧⌯───╯







''')















@shahm10.on(events.NewMessage(outgoing=False, pattern='/point1'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_username)







    await shahm10.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm10.on(events.NewMessage(outgoing=False, pattern='/point2'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernamee)







    await shahm10.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm10.on(events.NewMessage(outgoing=False, pattern='/point3'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernameee)







    await shahm10.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm10.on(events.NewMessage(outgoing=False, pattern='/point4'))







async def _(event):







    await event.reply("**جاري تجميع النقاط**")







    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernameeee)







    await shahm10.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm10.on(events.NewMessage(outgoing=True, pattern=".تجميع المليار"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_username)







    await shahm10.send_message(bot_username, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_username, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_username, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_username, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_username, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







    







    







    







@shahm10.on(events.NewMessage(outgoing=True, pattern=".تجميع الجوكر"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernamee)







    await shahm10.send_message(bot_usernamee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernamee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")















@shahm10.on(events.NewMessage(outgoing=True, pattern=".تجميع العقاب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernameee)







    await shahm10.send_message(bot_usernameee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernameee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")























@shahm10.on(events.NewMessage(outgoing=True, pattern=".تجميع العرب"))







async def _(event):















    await event.edit("**جاري تجميع النقاط**")







    joinu = await shahm10(JoinChannelRequest('ql8ql'))







    channel_entity = await shahm10.get_entity(bot_usernameeee)







    await shahm10.send_message(bot_usernameeee, '/start')







    await asyncio.sleep(4)







    msg0 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg0[0].click(2)







    await asyncio.sleep(4)







    msg1 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(0)















    chs = 1







    for i in range(100):







        await asyncio.sleep(4)















        list = await shahm10(GetHistoryRequest(peer=channel_entity, limit=1,







                                               offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))







        msgs = list.messages[0]







        if msgs.message.find('لا يوجد قنوات في الوقت الحالي , قم يتجميع النقاط بطريقه مختلفه') != -1:







            await shahm10.send_message(event.chat_id, f"**تم الانتهاء من التجميع | sh**")















            break







        url = msgs.reply_markup.rows[0].buttons[0].url







        try:







            try:







                await shahm10(JoinChannelRequest(url))







            except:







                bott = url.split('/')[-1]







                await shahm10(ImportChatInviteRequest(bott))







            msg2 = await shahm10.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='تحقق')







            chs += 1







            await event.edit(f"**تم الانضمام في {chs} قناة**")







        except:







            msg2 = await shahm10.get_messages(bot_usernameeee, limit=1)







            await msg2[0].click(text='التالي')







            chs += 1







            await event.edit(f"**القناة رقم {chs}**")







    await shahm10.send_message(event.chat_id, "**تم الانتهاء من التجميع | sh**")







































@shahm6.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm6.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm6.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm6.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm6.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm6.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm6.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm6.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm6.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm6.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm6.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm6.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm6.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm6.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm6(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm7.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm7.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm7.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm7.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm7.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm7.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm7.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm7.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm7.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm7.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm7.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm7.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm7.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm7.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm7(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm8.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm8.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm8.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm8.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm8.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm8.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm8.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm8.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm8.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm8.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm8.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm8.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm8.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm8.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm8(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm9.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm9.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm9.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm9.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm9.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm9.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm9.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm9.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm9.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm9.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm9.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm9.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm9.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm9.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm9(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







                































@shahm10.on(events.NewMessage(outgoing=False, pattern=r'^/pt1 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_username, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm10.send_message(bot_username, pt)







    sleep(2)







    msg = await shahm10.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'^/pt2 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm10.send_message(bot_usernamee, pt)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)















@shahm10.on(events.NewMessage(outgoing=False, pattern=r'^/pt3 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm10.send_message(bot_usernameee, pt)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'^/pt4 (.*)'))







async def OwnerStart(event):







    pt = event.pattern_match.group(1) 







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(3)







    sleep(2)







    await shahm10.send_message(bot_usernameeee, pt)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'/npoint1'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_username, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_username, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm10.get_messages(bot_username, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'/npoint2'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernamee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernamee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernamee, limit=1)















    await msg[0].forward_to(ownerhson_id)







 







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'/npoint3'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernameee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernameee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernameee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    







@shahm10.on(events.NewMessage(outgoing=False, pattern=r'/npoint4'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







     send = await shahm10.send_message(bot_usernameeee, '/start')







     sleep(2)







    msg1 = await shahm10.get_messages(bot_usernameeee, limit=1)







    await msg1[0].click(5)







    sleep(2)







    msg = await shahm10.get_messages(bot_usernameeee, limit=1)















    await msg[0].forward_to(ownerhson_id)







    















@shahm10.on(events.NewMessage(outgoing=False, pattern=r'/lpoint'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







        dialogs = await shahm10.get_dialogs()







        for dialog in dialogs:







            if dialog.is_channel:







                await shahm10(LeaveChannelRequest(dialog.entity))







                await event.respond(f"**قمت بمغادرة جميع القنوات والمجموعات**")







       















@shahm6.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm6.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**")    







    







    







@shahm7.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm7.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**")    







    







@shahm8.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm8.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 















@shahm9.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm9.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 















@shahm10.on(events.NewMessage(pattern=r'^/send (.*) (.*)'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id:







     usern = event.pattern_match.group(1)







    mase = event.pattern_match.group(2)







    await shahm10.send_message(usern, mase)







    await event.respond(f"**تـم ارسال الرسالة الى المستخدم {usern}**") 























@shahm6.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm7.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm8.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")























@shahm9.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")















@shahm10.on(events.NewMessage(outgoing=False, pattern='/transfer'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا بك في قسم تحويل النقاط







        







• @ZMMBOT - `/pt1 + عدد النقاط `







• @A_MAN9300BOT - `/pt2 + عدد النقاط`







• @MARKTEBOT - `/pt3 + عدد النقاط `







• @XNSEX21BOT - `/pt4 + عدد النقاط`**""")























@shahm6.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm7.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm8.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")























@shahm9.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")















@shahm10.on(events.NewMessage(outgoing=False, pattern='/infoacc'))







async def OwnerStart(event):







    sender = await event.get_sender()







    if sender.id == ownerhson_id :







        order = await event.reply("""**مرحبا في قسم معلومات الحسابات 







• @ZMMBOT - `/npoint1`







• @A_MAN9300BOT - `/npoint2`







• @MARKTEBOT - `/npoint3`







• @XNSEX21BOT - `/npoint4`**""")























print("💠 shahm Userbot Running 💠")







shahm1.run_until_disconnected()







shahm2.run_until_disconnected()







shahm3.run_until_disconnected()







shahm4.run_until_disconnected()







shahm5.run_until_disconnected()







shahm6.run_until_disconnected()







shahm7.run_until_disconnected()







shahm8.run_until_disconnected()







shahm9.run_until_disconnected()







shahm10.run_until_disconnected()







#code skip accumulate points by t.me.zzzzl1l thank you my bro







